module RSS
  # The current version of RSS
  VERSION = "0.3.0"
end
